''' hybrid.py The purpose of this program is to provide the core functionality to Vyrtuous.
    Copyright (C) 2024  github.com/brandongrahamcobb

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
'''
from discord.ext import commands
from datetime import datetime
from os.path import abspath, dirname, expanduser, join

import asyncio
import bot.utils.openai_helpers as openai_helpers
import bot.utils.helpers as helpers
import discord
import os

CHECKMARK_EMOJI = '✅'
CROSS_EMOJI = '❌'
dir_base = dirname(abspath(__file__))
path_openai_helpers = join(dir_base, '..', 'utils', 'openai_helpers.py')
path_home = expanduser('~')
path_indica = join(dir_base, '..', 'cogs', 'indica.py')
path_main = join(dir_base, '..', 'main.py')
path_sativa = join(dir_base, '..', 'cogs', 'sativa.py')

class Indica(commands.Cog):

    def __init__(self, bot):
        self.bot = bot
        self.config = bot.config
        self.hybrid = self.bot.get_cog('Hybrid')
        self.sativa = self.bot.get_cog('Sativa')
        self.openai_helpers_py = helpers.load_contents(path_openai_helpers)
        self.hybrid_py = helpers.load_contents(path_hybrid)
        self.indica_py = helpers.load_contents(path_indica)
        self.main_py = helpers.load_contents(path_main)
        self.sativa_py = helpers.load_contents(path_sativa)
        self.sys_input = f"""
            Your main.py file is {self.main_py}.
            Your cogs are in cogs/ {self.hybrid_py}, {self.indica_py}, {self.sativa_py}.
            Your openai_helpers are in utils/ {self.openai_helpers_py}.
        """

class Hybrid(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.indica = self.bot.get_cog('Indica')
        self.path_requests = 'requests.json'
        self.path_results = 'results.json'
        self.sativa = self.bot.get_cog('Sativa')

    @commands.hybrid_command(name='request')
    async def request_openai(
        self,
        ctx: commands.Context,
        completions: int = commands.parameter(default=1, description='Number of completions'),
        conversation_id: str = commands.parameter(default='', description='Conversation id'),
        input_text: str = commands.parameter(default='', description='Input text'),
        max_tokens: int = commands.parameter(default=150, description='Max tokens'),
        model: str = commands.parameter(default='gpt-3.5-turbo', description="""
            gpt-4o-mini, gpt-4, gpt-4o
        """),
        stop: str = commands.parameter(default=None, description='Stop'),
        store: bool = commands.parameter(default=False, description='Queue or request completions'),
        stream: bool = commands.parameter(default=False, description='Stream On/Off'),
        sys_input: str = commands.parameter(default=None, description='System input'),
        temperature: float = commands.parameter(default=0.7, description='Temperature'),
        top_p: float = commands.parameter(default=1.0, description='Nucleus Sampling')
    ):
        """Handles a request to the OpenAI GPT-4 model."""
        request_data = {
            "max_tokens": max_tokens,  # Set maximum tokens
            "messages": [
                {
                    "role": "user",
                    "content": input_text  # User prompt content
                },
                {
                    "role": "system",
                    "content": sys_input  # User prompt content
                },
            ],
            "model": model,  # Specify the model you want to use
            "temperature": temperature,  # Set temperature for randomness
            "top_p": top_p,  # Set top_p for nucleus sampling
            "n": completions,  # Number of completions
            "stop": stop,  # Define stopping criteria if necessary
            "store": store,  # Define stopping criteria if necessary
            "stream": stream,  # If you want streaming responses
        }
        if store:
            request_data.update(
                {
                    "metadata":
                        {
                            "user": str(ctx.author.id),
                            "timestamp": str(datetime.utcnow())
                        }
                }
            )
            helpers.append_to_jsonl(request_data, self.path_requests)
            await ctx.send(f"Your request has been recorded! We will inform you of the result once processed.")
        else:
            async for response in openai_helpers.create_completion(completions=completions, conversation_id=conversation_id, input_text=input_text, max_tokens=max_tokens, model=model, stop=stop, store=store, stream=stream, sys_input=f'You are Lucy, the Discord bot. {self.sys_input}\n\n {sys_input}', temperature=temperature, top_p=top_p):
                message = await ctx.send(response.strip())
                await message.add_reaction(CHECKMARK_EMOJI)
                await message.add_reaction(CROSS_EMOJI)


async def setup(bot: commands.Bot):
    await bot.add_cog(Hybrid(bot))
