''' helpers.py  The purpose of this program is to provide generic python methods.
    Copyright (C) 2024 github.com/brandongrahamcobb

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
'''

from discord import Embed
from io import BytesIO
from os import makedirs
from os.path import abspath, dirname, exists, expanduser, isfile, join
from typing import Dict, Any

global logger

import datetime as dt
import discord
import json
import logging
import logging.handlers
import os
import traceback
import yaml

path_home = expanduser('~')
path_config_yaml = join(path_home, '.config', 'openai', 'config.yaml')
path_log = join(path_home, '.log', 'discord.log')
path_preferences = join('.config', 'openai', 'users.json')

def append_to_jsonl(data, filename: str) -> None:
    """Append a json payload to the end of a jsonl file."""
    json_string = json.dumps(data)
    with open(filename, "a") as f:
        f.write(json_string + "\n")

def create_embed(title, description, color=0x00ff00):
    return Embed(title=title, description=description, color=color)

def load_contents(path_to_file):
    if not exists(path_to_file):
        raise FileNotFoundError(f"The file at '{path_to_file}' does not exist.")
    try:
        with open(path_to_file, 'r', encoding='utf-8') as file:
            content = file.read()
        return content
    except Exception as e:
        raise IOError(f"An error occurred while reading the file: {e}")

def load_json(path_to_file):
    try:
        with open(path_to_file, 'r') as f:
            data = json.load(f)
        return data
    except FileNotFoundError:
        return {}
    except Exception as e:
        print(traceback.format_exc())
        return {}

def load_yaml(path_to_file):
    try:
        if not os.path.exists(path_to_file):
            return {}
        with open(path_to_file, 'r') as f:
            return yaml.safe_load(f) or {}
    except Exception as e:
        print(traceback.format_exc())

def increment_version(config: Dict[str, Any]):
    current_version = config['version']
    major, minor, patch = map(int, current_version.split('.'))
    patch += 1
    if patch >= 10:
        patch = 0
        minor += 1
    if minor >= 10:
        minor = 0
        major += 1
    new_version = f'{major}.{minor}.{patch}'
    config['version'] = new_version
    with open(path_config_yaml, 'w') as file:
        yaml.dump(config, file)

async def save_json(path_to_file, data):
    try:
        directory = os.path.dirname(path_to_file)
        if not os.path.exists(directory):
            os.makedirs(directory) 
        with open(path_to_file, 'w') as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        print(f"Error saving JSON: {traceback.format_exc()}")

async def save_yaml(path_to_file, data):
    try:
        with open(path_to_file, 'w') as f:
            yaml.dump(data, f)
    except Exception as e:
        print(traceback.format_exc())


def setup_logging(config: Dict[str, Any]) -> None:
    logging_level = config['logging_level'].upper()
    logging.basicConfig(level=getattr(logging, logging_level))
    if not exists(dirname(path_log)):
        makedirs(dirname(path_log))
    file_handler = logging.FileHandler(path_log)
    file_handler.setLevel(logging_level)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    logger = logging.getLogger()
    logger.setLevel(logging_level)
    logger.addHandler(file_handler)
